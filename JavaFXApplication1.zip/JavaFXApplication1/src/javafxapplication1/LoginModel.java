/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplication1;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Administrateur
 */
public class LoginModel {
    
  Connection connection;
   
   public  LoginModel(){
       connection = SqliteConnection.Connector();
       if(connection == null){
           System.exit(1);
       }
   }
   
   public boolean isDbConnected(){
       try {
           return connection.isOpen();
       }
       catch(Exception e){
           return false;
       }
   }
   
   public static boolean LogingNow(String user, String pass){
       PreparedStatement preparedstatement =null;
       ResultSet resultSet = null ;
       String query = " select * from Studentlist where username = ? and password = ?";
       try {
           preparedstatement = connection.preparedStatement(query);
           preparedstatement.setString(1, user);
           preparedstatement.setString(2, pass);
           
           resultSet = preparedstatement.executeQuery();
           
           if(resultSet.next()){
               return true;
           }
           else {
               return false;
           }
       }
       catch(Exception e){
           return false;
       }
       finally{
           preparedstatement.close();
           resultSet.Close();
       }
       
   }
}
