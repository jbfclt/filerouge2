/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplication1;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Administrateur
 */
public class StudentData {
    private final StringProperty ID;
    private final StringProperty FIRSTNAME;
    private final StringProperty LASTNAME;
    
    public StudentData(String id, String firstname, String lastname){
        this.ID = new SimpleStringProperty(id);
        this.FIRSTNAME = new SimpleStringProperty(firstname);
        this.LASTNAME = new SimpleStringProperty(lastname);
        
    }
    
    public StringProperty IDProperty(){
        return this.ID;
    }
    
    public String getId(){
        return this.IDProperty().get();
    }
    
    public void setId(final String ID){
        this.IDProperty().set(ID);
    }
    public StringProperty firstnameProperty(){
        return this.ID;
    }
    
    public String getFirstname(){
        return this.IDProperty().get();
    }
    
    public void setFirstname(final String ID){
        this.IDProperty().set(ID);
    }
    public StringProperty lastnameProperty(){
        return this.ID;
    }
    
    public String getLastName(){
        return this.IDProperty().get();
    }
    
    public void setLastName(final String ID){
        this.IDProperty().set(ID);
    }
    
}
