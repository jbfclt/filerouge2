/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxapplication1;

import java.awt.Desktop.Action;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class LoginController implements Initializable {
    
    public LoginModel loginModel = new LoginModel();
    @FXML
    private Label mylabel;
    
    private TextField texteFieldName;
    private TextField texteFieldPass;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if(loginModel.isDbConnected()){
            mylabel.setText("Succesfully access to database");
        }
        else{
            mylabel.setText("Not succefully connected");
        }
    }    
    
    public void LogingChech(Action event){
     
          try{
             if(LoginModel.LogingNow(texteFieldName.getText(), texteFieldPass.getText())){
                 mylabel.setText("Valid username and password");  
                 
                 Stage stage =(Stage)this.texteFieldPass.getScene().getWindow();
                 stage.close;
                 OpenPage(event);
            }
             else{
                 mylabel.setText(("Invalid username and password"));
               }  
          }
          catch(Exception e ){
              e.printStackTrace();
              mylabel.setText("invalid usernamer or password");
          }
      } 
    
    public void OpenPage( Action event){
                Stage primaryStage = Stage();
                Scene scene = new Scene(root, 300, 250);
        
                primaryStage.setTitle("Hello World!");
                primaryStage.setScene(scene);
                primaryStage.show();
    }
}
