/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplication1;

import com.sun.jdi.connect.spi.Connection;
import java.sql.*;

/**
 *
 * @author Administrateur
 */
public class SqliteConnection {
    
    public static Connection Connector()
    {
        try {
            Class.forName("ord.sqlite.JDBC");
            Connection conn;
            //conn = DriverManeger.getConnection("jdbc:sqlite:C:\\Users\\Public\\Desktop/Student.sqlite");
            //return conn;
            return null;
        }
        catch(Exception e){
            return null;
        }
    }
    
}
